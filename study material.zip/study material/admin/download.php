<html>
<head>
<script language="javascript" type="text/javascript">

</script>
<link type="text/css" rel="stylesheet"/>
<title>
</title>
</head>
<body background="../images/fff.jpg">
<form action="download123.php" method="GET">
<table border="2" align="center" valign="middle" width="100%" id="login" >
<tr>
<td colspan="2"><img src="../images/banner1.jpg" width="100%" height="200"></img></td>
</tr>
<tr>
<td colspan="2"><?php include "hmenu.php";?></td>
</tr>
<tr><td colspan="2">
<table id="course" align="center">
<tr><td>Course Name</td><td>
<?php
include "../DBConnection.php";
$rs=mysql_query("select cname from course_2");
echo "<select name=course>";
echo "<option><--Select--></option>";
while($row=mysql_fetch_array($rs))
echo "<option>$row[cname]</option>";
echo "</select>";
?>
</td></tr>
<tr><td>Subject</td>
<td>
<?php
$rs=mysql_query("select subject  from course_2");
echo "<select name=subject>";
echo "<option><--Select--></option>";
while($row=mysql_fetch_array($rs))
echo "<option>$row[subject]</option>";
echo "</select>";
?>
</td></tr>
<tr align="center"><td colspan="2">
<input type="submit" value="download" name="download"> 
<?php
if(isset($_REQUEST["download"]))
{
$course=$_REQUEST["course"];
$subject=$_REQUEST["subject"];
$q="select * from course_2 where cname='$course' and subject='$subject'";
$rs=mysql_query($q);
echo "<table>";
echo "<tr><th>SUBJECT</th><th>AUTHOR</th><th>TITLE</th><th>Download</th></tr>";
while($row=mysql_fetch_array($rs))
	{
	echo "<tr>";
	echo "<td>$row[cname]</td>";
	echo "<td>$row[subject]</td>";
	echo "<td>$row[filename]</td>";
	echo "<td><a href=retdoc.php?id=$row[id] style=color:blue>Download</a></td>";
	echo "</tr>";
	}
echo "</table>";
}
?>
</td></tr>
</table>
</td></tr>
<tr><td colspan="2" align="center"></td></tr>
</table>
</form>
</body>
</html>