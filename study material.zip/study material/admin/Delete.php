<html>
<head>
<link href="css/look.css" type="text/css" rel="stylesheet"/>
<title>
</title>
</head>
<body background="../images/fff.jpg">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
<td colspan="2"><img src="../images/banner1.jpg" width="100%" height="200"></img></td>
</tr>
</tr>
<tr>
<td colspan="2"><?php include "hmenu.php";?></td>
</tr></table>
<br>
<br>
<body>
<?php
$con=mysqli_connect("localhost","root","","notesdb");
if (mysqli_connect_errno()) 
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$id=$_REQUEST['userD'];
$user_name;
$result = mysqli_query($con,"SELECT * FROM new_user");
while($row = mysqli_fetch_array($result)) 
{

	$un=$row['username'] ;
	if($un==$id)
		{
		mysql_query("delete from new_user where $id=$un");
			echo "Deleted";
		
			}
			
	/*else
	{
			echo "not found";
	}*/
		
}

?> 
</body></table>
</html>