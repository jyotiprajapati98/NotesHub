<html>
<head>
<link href="css/look.css" type="text/css" rel="stylesheet"/>
<title>
</title>
</head>
<body background="../images/fff.jpg">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
<td colspan="2"><img src="../images/banner1.jpg" width="100%" height="200"></img></td>
</tr>
</tr>
<tr>
<td colspan="2"><?php include "hmenu.php";?></td>
</tr></table>
<br>
<br>
<?php
$con=mysqli_connect("localhost","root","","notesdb");
if (mysqli_connect_errno()) 
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$result = mysqli_query($con,"SELECT * FROM new_user");
echo "<table border='1' align='center'>
<tr>
<th>Username</th>
<th>D_O_B</th>
<th>Gender</th>
<th>Email_Id</th>
<th>Course</th>
<th>Sem</th>
</tr>";
while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['username'] . "</td>";
  echo "<td>" . $row['d_o_b'] . "</td>";
  echo "<td>" . $row['gender']   . "</td>";
  echo "<td>" . $row['email_id'] . "</td>";
  echo "<td>" . $row['course']   . "</td>";
  echo "<td>" . $row['sem']      . "</td>";
  echo "</tr>";
}
echo "</table>";
echo"Delete Data.</br>";
echo"<form action='delete.php' method='post'>
<table align='center'>
<td><tr>
Enter User Name To Be Delete<input type='text' name='userD' /> </tr></td>
<td><tr>
<input type='submit' value='ok'>";

mysqli_close($con);
?>
<a href="delete.php"</a>
</body>

</html>