<html>
<head>
<link href="css/look.css" type="text/css" rel="stylesheet"/>
<title>
</title>
</head>
<body background="../images/fff.jpg">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
<td colspan="2"><img src="../images/banner1.jpg" width="100%" height="200"></img></td>
</tr>
<tr>
<td colspan="2"><?php include "hmenu.php";?></td>
</tr>
<tr>
<td width="80%" valign="top" align="center" height="300">
</td>
</tr>
<tr>
<td colspan="2" align="center"><marquee bgcolor="#990000">study material</marquee> </td>
</tr>
</table>
</body>
</html>