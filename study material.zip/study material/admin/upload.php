<?php
include "../dbconnection.php";
if(isset($_REQUEST["upload"]) && ($_FILES["userfile"]["size"] > 0))	
{
$rs=mysql_query("select * from  course_2"); 
$count=mysql_num_rows($rs);
if($count==0)
$count=1;
else
$count++;
$cname=$_REQUEST["cname"];
$subject=$_REQUEST["subject"];
$fileName = $_FILES["userfile"]["name"];
$tmpName  = $_FILES["userfile"]["tmp_name"];
$fileType = $_FILES["userfile"]["type"];
$fileSize = ($_FILES["userfile"]["size"]/1024). " kB<br>";
$fp  = fopen($tmpName, 'r');
$content = fread($fp, filesize($tmpName));
$content = addslashes($content);
fclose($fp);
$query = "INSERT INTO course_2 VALUES ('$count','$cname','$subject','$fileName', '$fileType','$fileSize','$content')";
mysql_query($query) or die(mysql_error()); 
echo '<script language="javascript">';
echo 'alert("DATA INSERTED")';
echo '</script>';
//header("Location:noteuploading.php?flag=true");
} 
?>
<html>
<head>
<style type="text/css">
	.login{
	font-size:95%;
	font-family:Arial, Helvetica, sans-serif;
	position: relative;
	width:445px;
}

.login_side{
	height: 280px;
	width:186px;
	padding: 0 10px 0 10px;
	float: left;
	border: 4px solid #ccc;
	border-right:none;
	-webkit-border-top-left-radius: 20px;
	-webkit-border-bottom-left-radius: 20px;
	-moz-border-radius-topleft: 20px;
	-moz-border-radius-bottomleft: 20px;
	border-top-left-radius: 20px;
	border-bottom-left-radius: 20px;

background: #b21a03; /* Old browsers */
background: -moz-linear-gradient(top,  #b21a03 0%, #7c2100 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#b21a03), color-stop(100%,#7c2100)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* IE10+ */
background: linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b21a03', endColorstr='#7c2100',GradientType=0 ); /* IE6-9 */


}

.login_inside h2, .login_side a{
	color: #FFF;
}
.login_inside p{
	line-height:.5em;
}

.login_inside h2{
	font-size:2em;
}
.login_inside a{
	font-size:.8em;
	text-decoration:none;
	border-bottom: double #B21A03 1px;
}

form {
	float: right;
    width: 200px;
    height: 240px;
    padding: 20px 15px;
    border: 4px solid #ccc;
    border-left: 1px solid #ccc;
    color: #000;
    font-size:.8em;
 
	/*** Rounded Corners ***/
	-webkit-border-top-right-radius: 20px;
	-webkit-border-bottom-right-radius: 20px;
	-moz-border-radius-topright: 20px;
	-moz-border-radius-bottomright: 20px;
	border-top-right-radius: 20px;
	border-bottom-right-radius: 20px;
 
/* Opera 11.10+ */
background: -o-linear-gradient(top, rgba(228,228,230,1), rgba(153,153,153,1));

/* Firefox 3.6+ */
background: -moz-linear-gradient(top, rgba(228,228,230,1), rgba(153,153,153,1));

/* Chrome 7+ & Safari 5.03+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0, rgba(228,228,230,1)), color-stop(1, rgba(153,153,153,1)));

/* IE5.5 - IE7 */
filter: progid:DXImageTransform.Microsoft.Gradient(GradientType=0,StartColorStr=#FFE4E4E6,EndColorStr=#FF999999);

/* IE8 */
-ms-filter: "progid:DXImageTransform.Microsoft.Gradient(GradientType=0,StartColorStr=#FFE4E4E6,EndColorStr=#FF999999)"
 
}

.input {
    width: 200px;
    background: #f8f8f8;
    padding: 6px;
    margin-bottom: 10px;
    border-top: 0px;
    border-left: 0px;
    border-right: 0px;
    border-bottom: 0px solid #ffffff;

    /*** Transition Selectors - What properties to animate and how long ***/
    -webkit-transition-property: -webkit-box-shadow, background;
    -webkit-transition-duration: 0.25s;

    -webkit-box-shadow: inset 0px 1px 3px 0px #444;
	-moz-box-shadow: inset 0px 1px 3px 0px #444;
	box-shadow: inset 0px 1px 3px 0px #444;

	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
}

.submit{
    width: 70px;
    float: right;
    background: #7C2100;
    padding: 4px;
    margin: 10px;
    border-top: 1px solid #B21A03;
    border-left: 1px solid #B21A03;
    border-right: 0px;
    border-bottom: 0px;
    cursor: pointer;
    color: #FFF;
    font-size:.9em;

    /*** Transition Selectors - What properties to animate and how long ***/
    -webkit-transition-property: -webkit-box-shadow, background;
    -webkit-transition-duration: 0.25s;

    -webkit-box-shadow: 0px 1px 3px 0px #666;
	-moz-box-shadow: 0px 1px 3px 0px #666;
	box-shadow: 0px 1px 3px 0px #666;

	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
</style>
</head>
<body background="../images/fff.jpg">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
<td colspan="2"><img src="../images/banner1.jpg" width="100%" height="200"></img></td>
</tr>
<tr>
<td colspan="2"><?php include "hmenu.php";?></td>
</tr>
<tr>
<td width="80%" valign="top" align="center" height="300">
<br>
<br>
<br>
<div class="login">
<div class="login_side">
<div class="login_inside">
<br>
<br>
<br>
<h2>DATA</h2>
<h2>UPLOADING</h2>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div></div>
<form enctype="multipart/form-data" action="upload.php" method="post" >
<table>
<tr>
<td>
<label>Course</label>
<?php
include "../dbconnection.php";
$rs=mysql_query("select distinct(cname) from course");
echo "<select name=cname class=input>";
echo "<option><--select--></option>";
while($row=mysql_fetch_array($rs))
{
echo "<option>$row[cname]</option>";
}
echo "</select>";
?>
</td>
</tr>
<tr>
<td>
<label>Subject</label>
<?php
include "../dbconnection.php";
$rs=mysql_query("select distinct(subject) from course");
echo "<select name=subject class=input>";
echo "<option><--select--></option>";
while($row=mysql_fetch_array($rs))
{
echo "<option>$row[subject]</option>";
}
echo "</select>";
?>
</td>
</tr>
<tr>
<td>
<label>File For Upload</label>
<input class="input" type="file" name="userfile" />
<input type='hidden' name='MAX_FILE_SIZE' value='100000000' /
</td>
</tr>
</table>
<input type="submit" value="Upload" name="upload" class="submit"/>
<input type="reset" value="Reset" name="reset" class="submit"/>
</form>
</div>
</td>
</tr>
<tr>
<td colspan="0" align="center"> <br>
</td>
</tr>
</table>
</body>
</html>