<?php
include "dbconnection.php";
mysql_query("insert into course values('1','$_REQUEST[cname]','$_REQUEST[subject]','$_REQUEST[sem]')");
alert "DATA INSERTED"
?>