<?php
include "condb.php";
if(isset($_POST['Register']) && $_FILES['userfile']['size'] > 0)
{
	$rs=mysql_query("select max(id) from uploading");
	$autonum=0;
	if($row=mysql_fetch_array($rs))
	{
		if($row[0]==0)
		$autonum=101;
		else
		{
			$autonum=$row[0];
			$autonum++;
		}
	}
$branch=$_REQUEST["branch"];
$subject=$_REQUEST["subject"];
$sem=$_REQUEST["sem"];
$authorname=$_REQUEST["k1"];
$title = $_REQUEST["k2"];
$fileName = $_FILES['userfile']['name'];
$tmpName = $_FILES['userfile']['tmp_name'];
$fileType = $_FILES['userfile']['type'];
$fileSize = $_FILES['userfile']['size'];
$fp  = fopen($tmpName, 'r');
$content = fread($fp, filesize($tmpName));
$content = addslashes($content);
fclose($fp);
$query = "INSERT INTO uploading VALUES ($autonum,'$branch','$subject',$sem,'$authorname','$title','$fileName', '$fileType',$fileSize, '$content')";
mysql_query($query,$con) or die(mysql_error()); 
//header("Location:noteuploading.php?flag=true");

} 
?>