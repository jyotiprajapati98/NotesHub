<html>
<head>
<script language="javascript" type="text/javascript">
window.history.forward();
</script>
<link href="css/look.css" type="text/css" rel="stylesheet"/>
<title>
</title>
</head>
<body>
<table border="1" width="100%" cellspacing="0" cellpadding="0">
<tr>
<td colspan="2"><img src="banner/books1.jpg" width="100%" height="300"></img></td>
<tr>
<td colspan="2"><?php include "hmenu.php";?></td>
</tr>
<tr><td colspan="2">
<form  method="post" enctype="multipart/form-data" action="noteuploading.php">>
<table border="1" align="center" valign="middle" id="login">
<pre>
<tr><td>Branch </td><td>
<?php
include "../DBConnection.php";
$rs=mysql_query("select distinct(bname) from course_tb");
echo "<select name=branch ";
echo "<option><--Select--></option>";
while($row=mysql_fetch_array($rs))
echo "<option>$row[bname]</option>";
echo "</select>";
?>
</td></tr>
<tr><td>Subject</td>
<td>
<?php
$rs=mysql_query("select sname  from course_tb");
echo "<select name=subject>";
echo "<option><--Select--></option>";
while($row=mysql_fetch_array($rs))
echo "<option>$row[sname]</option>";
echo "</select>";
?>
</td></tr>
<tr><td>Semester</td><td>
<select name="sem">
<option><--Select--></option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
</select>
</td></tr>
<tr><td>Authorname</td><td><input type="text" name="k1"></td></tr>
<tr><td>Title </td><td><input type="text" name="k2"></td></tr>
<tr><td>Notesupload</td><td><input type="file" name="userfile" id="userfile"></td></tr>
<tr align="center"><td colspan="2"><input type="submit" value="Register" name="Register"> <input type=Reset value="Reset"></td></tr>
</pre>
</table>
<?php
if(isset($_REQUEST["flag"]))
{
	echo "<script language=javascript>alert('Data Inserted');</script>";
}
?>
</form>
</td></tr>
<tr><td colspan="2" align="center">Develop by:abc</td></tr>
</table>
</body>
</html>
