<!doctype html>
<html lang=''>
<head>
<meta charset='utf-8'>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles.css">
<script src="script.js"></script>
</head>
<body>
<div id='cssmenu'>
<ul>
<li class='active'><a href="index.php"><span>Home</span></a></li>
<li><a href="aboutus.php"><span>About Us</span></a></li>
<li><a href="contactus.php"><span>Contact Us</span></a></li>
<li class='last'><a href="login.php"><span>Login</span></a></li>
</ul>
</div>
</body>
<html>
