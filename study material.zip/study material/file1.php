<?php
include "../Noteshub1/condb.php";
if(isset($_REQUEST["upload"]) && ($_FILES["userfile"]["size"] > 0))	
	
{
$rs=mysql_query("select * from  paper"); 
$count=mysql_num_rows($rs);
if($count==0)
$count=1;
else
$count++;
$year=$_REQUEST["year"];

$fileName = $_FILES["userfile"]["name"];
$tmpName  = $_FILES["userfile"]["tmp_name"];
$fileType = $_FILES["userfile"]["type"];
$fileSize = ($_FILES["userfile"]["size"]/1024). " kB<br>";
$fp  = fopen($tmpName, 'r');
$content = fread($fp, filesize($tmpName));
$content = addslashes($content);
fclose($fp);
$query = "INSERT INTO paper VALUES ('$count','$year','$subject','$fileName', '$fileType','$fileSize','$content')";
mysql_query($query) or die(mysql_error()); 
echo '<script language="javascript">';
echo 'alert("DATA INSERTED")';
echo '</script>';
//header("Location:noteuploading.php?flag=true");
} 
?>
</head>
<body>
<table width="100%" cellspacing="0" cellpadding="0">
<form action="file1.php" method="get">
<tr>
<td><input type="date" value="year" name="year"></td>
</tr>
<tr>
<td>
<label>File For Upload</label>
<input class="input" type="file" name="userfile" />
<input type='hidden' name='MAX_FILE_SIZE' value='100000000' /
</td>
</tr>
</table>
<input type="submit" value="Upload" name="upload" class="submit"/>
<input type="reset" value="Reset" name="reset" class="submit"/>
</form>
</div>
</td>
</tr>
<tr>
<td colspan="0" align="center"> <br>
</td>
</tr>
</td>
</form>
</table>
</body>
</html>