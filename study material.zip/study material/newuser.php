<?php
include "dbconnection.php";
if(isset($_REQUEST["Register"]))
{
$sr=mysql_query("select * from  new_user"); 
$count=mysql_num_rows($sr);
if($count==0)
{
$count=1;
}
else
{
$count++;
}
$rs=mysql_query("select * from new_user where username='$_REQUEST[username]'");
if(mysql_num_rows($rs)==0)
{
mysql_query("insert into new_user values('$count','$_REQUEST[username]','$_REQUEST[password]','$_REQUEST[dob]','$_REQUEST[r]','$_REQUEST[email]','$_REQUEST[course]','$_REQUEST[sem]')");
header("Location:newuser.php?flag=true");
}
else
header("Location:newuser.php?flag=false");

}
?>
<html>
<head>
<link href="css/look.css" type="text/css" rel="stylesheet"/>
<title>
</title>
<style type="text/css">
	.login{
	font-size:95%;
	font-family:Arial, Helvetica, sans-serif;
	position: relative;
	width:350px;
}

.login_side{
	height: 510px;
	width:106px;
	padding: 0 10px 0 10px;
	float: left;
	border: 4px solid #ccc;
	border-right:none;
	-webkit-border-top-left-radius: 20px;
	-webkit-border-bottom-left-radius: 20px;
	-moz-border-radius-topleft: 20px;
	-moz-border-radius-bottomleft: 20px;
	border-top-left-radius: 20px;
	border-bottom-left-radius: 20px;

background: #b21a03; /* Old browsers */
background: -moz-linear-gradient(top,  #b21a03 0%, #7c2100 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#b21a03), color-stop(100%,#7c2100)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* IE10+ */
background: linear-gradient(top,  #b21a03 0%,#7c2100 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#b21a03', endColorstr='#7c2100',GradientType=0 ); /* IE6-9 */


}

.login_inside h2, .login_side a{
	color: #FFF;
}
.login_inside p{
	line-height:.5em;
}

.login_inside h2{
	font-size:2em;
}
.login_inside a{
	font-size:.8em;
	text-decoration:none;
	border-bottom: double #B21A03 1px;
}

form {
	float: right;
    width: 185px;
    height: 470px;
    padding: 20px 15px;
    border: 4px solid #ccc;
    border-left: 1px solid #ccc;
    color: #290303;
    font-size:.8em;
 
	/*** Rounded Corners ***/
	-webkit-border-top-right-radius: 20px;
	-webkit-border-bottom-right-radius: 20px;
	-moz-border-radius-topright: 20px;
	-moz-border-radius-bottomright: 20px;
	border-top-right-radius: 20px;
	border-bottom-right-radius: 20px;
 
/* Opera 11.10+ */
background: -o-linear-gradient(top, rgba(228,228,230,1), rgba(153,153,153,1));

/* Firefox 3.6+ */
background: -moz-linear-gradient(top, rgba(228,228,230,1), rgba(153,153,153,1));

/* Chrome 7+ & Safari 5.03+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0, rgba(228,228,230,1)), color-stop(1, rgba(153,153,153,1)));

/* IE5.5 - IE7 */
filter: progid:DXImageTransform.Microsoft.Gradient(GradientType=0,StartColorStr=#FFE4E4E6,EndColorStr=#FF999999);

/* IE8 */
-ms-filter: "progid:DXImageTransform.Microsoft.Gradient(GradientType=0,StartColorStr=#FFE4E4E6,EndColorStr=#FF999999)"
 
}

.input {
    width: 170px;
    background: #f8f8f8;
    padding: 6px;
    margin-bottom: 10px;
    border-top: 0px;
    border-left: 0px;
    border-right: 0px;
    border-bottom: 1px solid #ffffff;

    /*** Transition Selectors - What properties to animate and how long ***/
    -webkit-transition-property: -webkit-box-shadow, background;
    -webkit-transition-duration: 0.25s;

    -webkit-box-shadow: inset 0px 1px 3px 0px #444;
	-moz-box-shadow: inset 0px 1px 3px 0px #444;
	box-shadow: inset 0px 1px 3px 0px #444;

	-webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
}

.submit{
    width: 70px;
    float: right;
    background: #7C2100;
    padding: 4px;
    margin: 10px;
    border-top: 1px solid #B21A03;
    border-left: 1px solid #B21A03;
    border-right: 0px;
    border-bottom: 0px;
    cursor: pointer;
    color: #FFF;
    font-size:.9em;

    /*** Transition Selectors - What properties to animate and how long ***/
    -webkit-transition-property: -webkit-box-shadow, background;
    -webkit-transition-duration: 0.25s;

    -webkit-box-shadow: 0px 1px 3px 0px #666;
	-moz-box-shadow: 0px 1px 3px 0px #666;
	box-shadow: 0px 1px 3px 0px #666;

	-webkit-border-radius: 3px;
	-moz-border-radius: 3px;
	border-radius: 3px;
}
</style>
<script language="javascript">
function validate()
{
	if(document.myform.username.value=="")
	{
		alert("please provide your name!");
		document.myform.firstname.focus();
		return false;
	}
	if(document.myform.password.value=="" || isNaN(document.myform.password.value)||document.myform.password.value.length !=6)
	{
		alert("please provide a password more than 6 digit");
		document.myform.pin.focus();
		return false;
	}
	/*if(document.myform.email.value=="")
	{
		alert("please provide your email!");
		document.myform.email.focus();
		return false;
	}*/
	
	
	if(document.myform.course.value=="-1")
	{
		alert("please provide your course!");
		return false;
	}
		if(document.myform.sem.value=="-1")
	{
		alert("please provide your sem!");
		return false;
	}
	


//function validateemail()

	var emailID=document.myform.email.value;
	atpos=emailID.indexOf("@");
	dotpos=emailID.lastIndexOf(".");
	if(atpos<1 ||(dotpos-atpos<2))
	{
	    alert("please enter your correct emailID");
		document.myform.email.focus();
		return false;	
	}
	return(true);
}
</script>

</head>
<body background="images/fff.jpg">
<table width="100%" cellspacing="0" cellpadding="0">
<tr>
<td colspan="2"><img src="images/banner1.jpg" width="100%" height="200"></img></td>
</tr>
<tr>
<td colspan="2"><?php include "hmenu.php";?></td>
</tr>
<tr>
<td width="80%" valign="top" align="cent1er" height="400">
<br>
<br>
<br>
<div class="login">
	<div class="login_side">
		<div class="login_inside">
		<br>
		<h2>NEW USER</h2>
	</div>
	</div>
<form method="#"action="newuser.php" name="myform" onSubmit="return(validate());">
<label>Login Name</label>
<input class="input" type="text" name="username"> <span id="errName" class="error"></span> 
<label>Password</label>
<input class="input" type="Password" name="password"  />
<label>Confirm Password</label>
<input class="input" type="Password" name="Cpassword"  />
<label>Date Of Birth</label>
<input class="input" type="date" name="dob"/>
<br>
<label>Gender</label><br>
Male<input  type="radio" value="Male" name="r" />
Female<input  type="radio"  value="FeMale" name="r" checked/>
<br>
<br>
<label>Roll number</label>
<input class="input" type="text" name="Roll number"/>
<label>Email ID</label>
<input class="input" type="text" name="email" />
<label>Course</label>
<select class="input" name="course">
<option value="CS">CS</option>
<option value="IT">IT</option>
<option value="MECH">MECH</option>
<option value="CIVIL">CIVIL</option>
<option value="ET&T">ET&T</option>
<option value="ELECTRICAL">ELECTRICAL</option>
<option value="MINING">MINING</option>
<option value="METULLURGY">METULLURGY</option>
</select>
<label>Sem/Year</label>
<select class="input" name="sem">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
</select>
<input type="submit" value="Register" name="Register" class="submit" />
<input type="Reset" value="Clear"  class="submit" />
</form>
<?php
if(isset($_REQUEST["flag"]))
{
	if($_REQUEST["flag"]=="true")
	echo "<script language=javascript>alert('Data Inserted');</script>";
	else
	echo "<script language=javascript>alert('user alrady exists');</script>";

}
?>
</div>
</td>
</tr>
<tr>
<td colspan="2" align="center"> </td>
</tr>
</table>
</body>
</html>