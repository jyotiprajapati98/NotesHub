<!doctype html>
<html lang=''>
<head>
<meta charset='utf-8'>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles.css">
<script src="script.js"></script>
</head>
<body>
<div id='cssmenu'>
<ul>
<li class='active'><a href="changepwd.php"><span>Change Password</span></a></li>
<li><a href="download123.php"><span>Download</span></a></li>
<li><a href="edit_form.php"><span>upload</span></a></li>
<li class='last'><a href="../login.php"><span>Log Out</span></a></li>
</ul>
</div>
</body>
<html>
