<?php
include "../DBConnection.php";
$sr=$_REQUEST["id"];
$rs=mysql_query("select filename,filetype,filesize,filedata from course_2  where id='$sr'");
$row=mysql_fetch_array($rs);
Header("Content-type: $row[filetype]");
header("Content-Disposition: attachment;filename=$row[filename]");
echo $row["filedata"];

?>